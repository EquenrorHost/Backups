<?php
/**
 * WHMCS NULLED
 * Version: 5.3.9
 * Author: MZN SHadows
 * Release on: 26-08-2014
 **/

define( 'ADMINAREA', true );
require( '../init.php' );
$aInt = new WHMCS_Admin( 'Browser' );
$aInt->title = $aInt->lang( 'utilities', 'browser' );
$aInt->sidebar = 'browser';
$aInt->icon = 'browser';

if ($action == 'delete') {
	check_token( 'WHMCS.admin.default' );
	delete_query( 'tblbrowserlinks', array( 'id' => $id ) );
	redir(  );
}


if ($action == 'add') {
	check_token( 'WHMCS.admin.default' );
	$siteurl = WHMCS_Input_Sanitize::decode( $whmcs->get_req_var( 'siteurl' ) );
	$siteurl = WHMCS_Filter_Input::url( $siteurl );

	if (!$siteurl) {
		redir( 'invalidurl=1' );
	}

	insert_query( 'tblbrowserlinks', array( 'name' => $sitename, 'url' => $siteurl ) );
	redir(  );
}

$url = 'http://www.mznshadows.com/ytinstantaneo/';
$link = $whmcs->get_req_var( 'link' );
$result = select_query( 'tblbrowserlinks', '', '', 'name', 'ASC' );

if ($data = mysql_fetch_assoc( $result )) {
	$browserlinks[] = $data;

	if ($data['id'] == $link) {
		$url = $data['url'];
	}
}

$aInt->assign( 'browserlinks', WHMCS_Input_Sanitize::makesafeforoutput( $browserlinks ) );
$content = '';

if ($whmcs->get_req_var( 'invalidurl' )) {
	infoBox( 'Invalid URL', 'Please enter a full and valid URL in a format such as http://www.domain.com/path/to/file.php' );
	$content .= $infobox;
}

$content .= '<iframe width="100%" height="580" src="' . $url . '" name="brwsrwnd" style="min-width:1000px;"></iframe>';
$aInt->deleteJSConfirm( 'doDelete', 'browser', 'deleteq', '?action=delete&id=' );
$aInt->content = $content;
$aInt->display(  );
?>
