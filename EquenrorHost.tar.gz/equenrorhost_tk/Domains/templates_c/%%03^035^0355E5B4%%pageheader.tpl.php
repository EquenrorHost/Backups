<?php /* Smarty version 2.6.28, created on 2014-09-20 05:18:56
         compiled from default/pageheader.tpl */ ?>
<div class="page-header">
    <div class="styled_title"><h1><?php echo $this->_tpl_vars['title']; ?>
<?php if ($this->_tpl_vars['desc']): ?> <small><?php echo $this->_tpl_vars['desc']; ?>
</small><?php endif; ?></h1></div>
</div>