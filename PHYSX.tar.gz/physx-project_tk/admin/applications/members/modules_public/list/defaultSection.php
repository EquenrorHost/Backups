<?php
/**
 * @file		defaultSection.php 	Define the default section for the 'list' module
 *~TERABYTE_DOC_READY~
 * $Copyright: (c) 2001 - 2011 Invision Power Services, Inc.$
 *
 * $Author: ips_terabyte $
 * @since		20th February 2002
 * $LastChangedDate: 2011-05-05 12:40:49 -0400 (Thu, 05 May 2011) $
 * @version		v3.4.6
 * $Revision: 8655 $
 */

$DEFAULT_SECTION = 'view';
