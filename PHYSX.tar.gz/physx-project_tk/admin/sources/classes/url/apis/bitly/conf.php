<?php

/**
 * <pre>
 * Invision Power Services
 * IP.Board v3.4.6
 * URL shortener
 * Owner: Matt Mecham
 * Last Updated: $Date: 2012-05-10 16:10:13 -0400 (Thu, 10 May 2012) $
 * </pre>
 *
 * @author 		Matt Mecham
 * @copyright	(c) 2001 - 2009 Invision Power Services, Inc.
 *
 * @package		IP.Board
 *
 * @since		24th November 2009
 * @version		$Revision: 10721 $
 */

$config = array();

/* Login... */
$config['login'] = 'invisionps';

/* API KEY - You can find your apiKey at http://bit.ly/account/your_api_key : */
$config['apiKey']  = 'R_eee8c282b147b0aed1bce4370ac81744';

